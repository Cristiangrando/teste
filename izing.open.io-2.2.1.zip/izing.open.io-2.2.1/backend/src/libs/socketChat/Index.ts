/* eslint-disable @typescript-eslint/ban-types */

// interface Shared {
//   tenantId: number | string;
//   sockets: [];
//   usersOnline: {};
//   idleUsers: {};
// }

export const shared: any = {};
