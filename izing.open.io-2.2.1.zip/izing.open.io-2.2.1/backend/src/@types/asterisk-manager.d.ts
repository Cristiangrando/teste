declare module "asterisk-manager";
